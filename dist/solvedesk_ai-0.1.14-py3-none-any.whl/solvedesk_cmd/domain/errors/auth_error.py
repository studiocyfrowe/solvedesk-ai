class AuthError(Exception):
    pass